# Redux Tests

This is a collection of samples for testing redux from [The Complete
Redux Book](http://redux-book.com)

## Setup

    npm install


## Running

    npm run test:watch

## License

Proprietary
