import { combineReducers } from 'redux';
import recipes from './recipes.js';

export default combineReducers({
  recipes
});