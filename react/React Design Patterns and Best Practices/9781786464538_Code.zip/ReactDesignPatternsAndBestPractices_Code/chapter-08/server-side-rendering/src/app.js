import React from 'react'

const App = () => <div>Hello React</div>

export default App
