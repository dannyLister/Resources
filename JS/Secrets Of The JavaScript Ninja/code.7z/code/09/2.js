// A simple example of markup that's capable of causing great confusion in development.

&lt;form id="form">
  &lt;input type="text" id="length"/>
  &lt;input type="submit" id="submit"/>
&lt;/form>