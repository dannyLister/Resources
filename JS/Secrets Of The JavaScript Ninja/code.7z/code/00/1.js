// Simple example of assert statements from our test suite.

assert( true, "This statement is true." );
assert( false, "This will never succeed." );