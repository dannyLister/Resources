// A case of using <code>with(){}</code> in the base2 JavaScript library.

with (document.body.style) {
  backgroundRepeat = "no-repeat";
  backgroundImage = 
    "url(http://ie7-js.googlecode.com/svn/trunk/lib/blank.gif)";
  backgroundAttachment = "fixed";
}